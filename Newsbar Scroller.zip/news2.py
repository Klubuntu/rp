import glob
import time
import os

# Define the source and destination file paths
source_file_pattern = "script*.txt"
destination_file = "obs_script.txt"

# Define the update interval (in seconds)
update_interval = 3

# Create a variable to track the manual reload button state
manual_reload_triggered = False

def refresh_code():
    # Find the latest source file matching the pattern
    source_files = glob.glob(source_file_pattern)
    latest_file = max(source_files, key=os.path.getmtime) if source_files else None

    if latest_file:
        # Read the content of the source file
        with open(latest_file, "r") as f:
            content = f.read()

        # Save the content to the destination file
        with open(destination_file, "w") as f:
            f.write(content + " "*10 + "2")

        # Reset the manual reload button state
        global manual_reload_triggered
        manual_reload_triggered = False

def manual_reload_pressed():
    # Set the manual reload button state to trigger a manual reload
    global manual_reload_triggered
    manual_reload_triggered = True

def main():
    # Start the timer for automatic refresh
    while True:
        # Update events
        refresh_code()

        # Handle manual reload if triggered
        if manual_reload_triggered:
            refresh_code()

        # Sleep for the specified interval
        time.sleep(update_interval)

# Run the main execution loop
if __name__ == "__main__":
    print("Server running in local")
    main()
