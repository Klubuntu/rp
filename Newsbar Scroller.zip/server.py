from flask import Flask, request, Response
import threading

app = Flask(__name__)

# Store the current text for the scrollbar
scrollbar_text = ""

# Store the list of connected clients
clients = []

@app.route('/api/scrollbar', methods=['POST'])
def update_scrollbar_text():
    global scrollbar_text

    # Get the new text from the request data
    new_text = request.form.get('text')
    print(new_text)

    # Update the scrollbar text
    scrollbar_text = new_text

    # Notify all connected clients about the updated text
    for client in clients:
        client.send(scrollbar_text)

    return 'Scrollbar text updated successfully.'

@app.route('/api/scrollbar', methods=['GET'])
def get_scrollbar_text():
    def event_stream():
        # Create a new client and add it to the list of connected clients
        client = Client()
        clients.append(client)

        # Continuously send the current scrollbar text to the client
        while True:
            client.receive(scrollbar_text)
            yield f"text: {scrollbar_text}\n\n"

    return Response(event_stream(), mimetype='text/event-stream')

@app.route('/', methods=['GET'])
def index():
    return app.send_static_file('app.html')

class Client:
    def __init__(self):
        self.queue = []
        self.event = threading.Event()

    def send(self, message):
        self.queue.append(message)
        self.event.set()

    def receive(self, message):
        self.event.wait()
        self.event.clear()
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if not self.queue:
            raise StopIteration
        return self.queue.pop(0)

if __name__ == '__main__':
    app.run()
